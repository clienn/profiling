<nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="#"></a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
    </button>
</nav><?php /**PATH D:\dustin\laravel_proj\profiling\resources\views/inc/topbar.blade.php ENDPATH**/ ?>