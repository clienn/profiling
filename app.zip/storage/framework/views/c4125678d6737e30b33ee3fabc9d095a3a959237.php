<svg xmlns="http://www.w3.org/2000/svg" width="41.659" height="26.552" viewBox="0 0 41.659 26.552">
    <defs>
        <style>
            .a {
                fill: #bcb7b7;
            }
        </style>
    </defs>
    <g transform="translate(0 -92.835)">
        <g transform="translate(0 92.835)">
            <g transform="translate(0 0)">
                <path class="a" d="M41.394,105.3c-.372-.509-9.24-12.466-20.565-12.466S.636,104.792.264,105.3a1.375,1.375,0,0,0,0,1.621c.372.509,9.24,12.466,20.565,12.466s20.193-11.957,20.565-12.465A1.373,1.373,0,0,0,41.394,105.3ZM20.829,116.64c-8.342,0-15.568-7.936-17.706-10.53,2.136-2.6,9.346-10.528,17.706-10.528,8.342,0,15.567,7.934,17.706,10.53C36.4,108.708,29.189,116.64,20.829,116.64Z" transform="translate(0 -92.835)" />
            </g>
        </g>
        <g transform="translate(12.589 97.871)">
            <path class="a" d="M162.962,154.725a8.24,8.24,0,1,0,8.24,8.24A8.25,8.25,0,0,0,162.962,154.725Zm0,13.734a5.493,5.493,0,1,1,5.493-5.493A5.5,5.5,0,0,1,162.962,168.459Z" transform="translate(-154.722 -154.725)" />
        </g>
    </g>
</svg><?php /**PATH D:\dustin\laravel_proj\profiling\resources\views/svg/view-eye-icon.blade.php ENDPATH**/ ?>