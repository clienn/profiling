<?php $__env->startSection('content-2'); ?>
<div class="row form-group align-items-center p-2">
    <div class="col-md-10 my-1">
        <input id="search" autocomplete="off" type="text" class="form-control" name="username" placeholder="Scan member QR code">
        
    </div>
    <div class="col-md-2 my-1">
        <!-- <button id="" type="submit" class="btn btn-primary mr-2 btn-rounded-4"> -->
        <button id="qr-scanner" type="button" class="btn btn-primary border-0 mr-2 btn-rounded-4" data-toggle="modal" data-target="#qrModal">
            <i class="fa icon-qr-1"></i>Scan QR Code
        </button>
    </div>
    
</div>

<script type="text/javascript">
    var qr_code = "<?php echo e(app('request')->input('qr_code')); ?>";

    function getScan() {
        $.get('/getScan', (data) => {
            //console.log(data);
            if (data && data.qr_code && qr_code != data.qr_code) {
                location.href = '/dashboard?qr_code=' + data.qr_code;
            }

            setTimeout(() => {   
                getScan()
            }, 3000);
        });
    }

    function updateScan() {
        apiCall("<?php echo e(env('APP_URL', '127.0.0.1:8001')); ?>/api/scan", 'PUT',
            JSON.stringify({
                id: "<?php echo e(Auth::user()->username); ?>",
                qr_code: $('#search').val()
            }),
            (data) => {
                // test
            }
        )
    }
    
    getScan();
    
    $(document).ready(function() {
        $('#qrModal').on('hidden.bs.modal', function () {
            updateScan();
        });

        $('#search').keyup(function(e) {
            if (e.keyCode == 13) {
                updateScan();
            }
        });
    });
</script>

<?php if(app('request')->input('qr_code') && $data): ?>
    <?php echo $__env->make('includes.search-result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('includes.search-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dustin\laravel_proj\profiling\resources\views/dashboard.blade.php ENDPATH**/ ?>