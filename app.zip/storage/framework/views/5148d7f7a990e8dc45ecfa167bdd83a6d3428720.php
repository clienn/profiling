<style>
    th {
        font-family: 'WorkSansRegular';
        font-size: 14px;
    }

    td {
        font-family: 'WorkSansRegular';
        font-size: 12px;
        
    }

    tr {
        padding-top:2em;
        padding-bottom:2em;
    }

</style>

<?php $__env->startSection('header-content'); ?>
<div class="row p-4 pt-1 pb-0" style="position:relative;top:-2em;margin-bottom:-4em;">
    <div class="col-md-12 p-0">
        <div class="row d-flex justify-content-between">
            <div class="col-md-3 container-fluid p-3">
                <div class="container-fluid shadow mt-3 mb-3 rounded bgc-0 p-4">
                    <div class="header-1 font-weight-bold"><?php echo e($leaders); ?></div>
                    <div class="header-6 font-weight-bold">Leaders</div>
                    <div class="header-8">Overall total leader count</div>
                </div>
            </div>
            <div class="col-md-3 container-fluid p-3">
                <div class="container-fluid shadow mt-3 mb-3 rounded bgc-0 p-4">
                    <div class="header-1 font-weight-bold"><?php echo e($members); ?></div>
                    <div class="header-6 font-weight-bold">Members</div>
                    <div class="header-8">Overall total member count</div>
                </div>
            </div>
            <div class="col-md-3 container-fluid p-3">
                <div class="container-fluid shadow mt-3 mb-3 rounded bgc-0 p-4">
                    <div class="header-1 font-weight-bold"><?php echo e($staffs); ?></div>
                    <div class="header-6 font-weight-bold">Staff</div>
                    <div class="header-8">Overall total staff count</div>
                </div>
            </div>
            <div class="col-md-3 container-fluid p-3">
                <div class="container-fluid shadow mt-3 mb-3 rounded bgc-0 p-4">
                    <div class="header-1 font-weight-bold"><?php echo e($overallPercentage); ?>%</div>
                    <div class="header-6 font-weight-bold">Level Member</div>
                    <div class="header-8">Overall total branch members</div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#sel1').change(function() {
            let page = "<?php echo e(app('request')->input('page')); ?>";
            if (!page) page = 1;
            location.href = '?page=' + page + '&records=' + $(this).val() + '#member-list';
        });

        $('#sel1 option').each(function() {
            if ($(this).val() == "<?php echo e(app('request')->input('records')); ?>") {
                $(this).attr('selected', true);
            }
        });

        $('#search').keyup(function(e) {
            if (e.keyCode == 13) {
                location.href = '?page=1&records=10&search=' + $(this).val();
            }
        });

        $('#qrModal').on('hidden.bs.modal', function () {
            location.href = '?page=1&records=10&search=' + $('#search').val();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-2'); ?>
<div class="row form-group align-items-center p-2">
    <div class="col-md-10 my-1">
        <input id="search" autocomplete="off" type="text" class="form-control" name="username" 
            placeholder="Enter search string or member QR code" />
        
    </div>
    <div class="col-md-2 my-1">
        <!-- <button type="submit" class="btn btn-primary mr-2 btn-rounded-4"> -->
        <button id="qr-scanner" type="button" class="btn btn-primary border-0 mr-2 btn-rounded-4" data-toggle="modal" data-target="#qrModal">
            <i class="fa icon-qr-1"></i>Scan QR Code
        </button>
    </div>
</div>

<?php if(count($data) > 0): ?>
<div class="row p-2 pt-0">
    <div class="col-md-12">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col"><a class="nostyle" name="member-list" href="#">Lastname</a></th>
                    <th scope="col">Firstname</th>
                    <th scope="col">Middlename</th>
                    <th scope="col">Address</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($member->lastname); ?></td>
                        <td><?php echo e($member->firstname); ?></td>
                        <td><?php echo e($member->middlename); ?></td>
                        <td><?php echo e($member->address); ?></td>
                        <td><?php echo e($member->contact); ?></td>
                        <td><?php echo e($member->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="row p-2">
    <div class="col-md-12">
        <div class="row p-2 justify-content-between">
            <div class="col-md-2 text-left">
                <select name="rec_per_page" class="form-control fc-1 font-regular header-10" id="sel1">
                    <option value="1">Rows per page: 1</option>
                    <option value="2">Rows per page: 2</option>
                    <option value="5">Rows per page: 5</option>
                    <option value="10">Rows per page: 10</option>
                    <option value="15">Rows per page: 15</option>
                    <option value="20">Rows per page: 20</option>
                </select>
            </div>
            <div class="col-md-3 text-center mt-2">
                <span class="fc-1 font-regular header-10">
                    <?php echo e($from); ?> - <?php echo e($to); ?> 
                    of 
                    <?php echo e($total); ?>

                </span>
            </div>
            <div class="col-md-3 text-right">
                <div class="row d-flex justify-content-center">
                    <div class="col-md-1 text-right">
                        <div class="circle fc-1" style="position:relative;left:90%">
                            <a class="page-nav nostyle" href="<?php echo e($first); ?>">
                                <p class="font-regular header-10">|<</p>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-1 text-right">
                        <div class="circle" style="position:relative;left:90%">
                            <a class="page-nav nostyle" href="<?php echo e($prev); ?>">
                                <p class="fc-1 font-regular header-10"><</p>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-1 text-right">
                        <div class="circle" style="position:relative;left:90%">
                            <a class="page-nav nostyle" href="<?php echo e($next); ?>">
                                <p class="font-regular header-10">></p>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-1 text-right">
                        <div class="circle" style="position:relative;left:90%">
                            <a class="page-nav nostyle p-0 m-0" href="<?php echo e($last); ?>">
                                <p class="fc-1 font-regular header-10">>|</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
    <?php echo $__env->make('includes.search-notfound', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dustin\laravel_proj\profiling\resources\views/member.blade.php ENDPATH**/ ?>