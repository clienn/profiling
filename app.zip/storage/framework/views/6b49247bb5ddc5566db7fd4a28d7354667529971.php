<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="258.22" height="238.871" viewBox="0 0 258.22 238.871">
    <defs>
        <style>
            .a {
                fill: #fff;
            }
            
            .b,
            .z {
                opacity: 0.5;
            }
            
            .c {
                fill: url(#a);
            }
            
            .d {
                fill: #e6e6e6;
            }
            
            .e {
                fill: #e0e0e0;
            }
            
            .f,
            .i,
            .u {
                fill: #6c63ff;
            }
            
            .f,
            .l {
                opacity: 0.7;
            }
            
            .g {
                fill: #f5f5f5;
            }
            
            .h {
                clip-path: url(#d);
            }
            
            .i,
            .j {
                opacity: 0.4;
            }
            
            .j {
                fill: #bdbdbd;
            }
            
            .k {
                fill: url(#h);
            }
            
            .l {
                fill: #3ad29f;
            }
            
            .m {
                fill: url(#i);
            }
            
            .n {
                fill: #214ab9;
            }
            
            .o {
                fill: #496ac3;
            }
            
            .p {
                fill: #4771e7;
            }
            
            .q {
                fill: #ffb100;
            }
            
            .r {
                fill: url(#j);
            }
            
            .s {
                fill: url(#k);
            }
            
            .t {
                fill: url(#l);
            }
            
            .v,
            .z {
                fill: #47e6b1;
            }
            
            .w {
                fill: #4d8af0;
            }
            
            .x {
                fill: #fdd835;
            }
            
            .y {
                fill: #f55f44;
            }
        </style>
        <linearGradient id="a" x1="0.5" y1="1" x2="0.5" gradientUnits="objectBoundingBox">
            <stop offset="0" stop-color="gray" stop-opacity="0.251" />
            <stop offset="0.54" stop-color="gray" stop-opacity="0.122" />
            <stop offset="1" stop-color="gray" stop-opacity="0.102" />
        </linearGradient>
        <clipPath id="d">
            <rect class="a" width="44.097" height="29.726" />
        </clipPath>
        <linearGradient id="h" x1="0.518" y1="1.092" x2="0.518" y2="-0.251" xlink:href="#a" />
        <linearGradient id="i" x1="0.6" y1="0.66" x2="0.6" y2="0.086" xlink:href="#a" />
        <linearGradient id="j" x1="0.5" y1="1" x2="0.5" gradientUnits="objectBoundingBox">
            <stop offset="0" stop-color="#b3b3b3" stop-opacity="0.251" />
            <stop offset="0.54" stop-color="#b3b3b3" stop-opacity="0.102" />
            <stop offset="1" stop-color="#b3b3b3" stop-opacity="0.051" />
        </linearGradient>
        <linearGradient id="k" x1="0.5" y1="0.999" x2="0.5" gradientUnits="objectBoundingBox">
            <stop offset="0" stop-opacity="0.122" />
            <stop offset="0.55" stop-opacity="0.09" />
            <stop offset="1" stop-opacity="0.02" />
        </linearGradient>
        <linearGradient id="l" x1="0.5" y1="1" x2="0.5" y2="0" xlink:href="#k" />
    </defs>
    <g transform="translate(0 0.017)">
        <g class="b" transform="translate(47.274 39.921)">
            <rect class="c" width="137.526" height="184.803" />
        </g>
        <rect class="d" width="133.229" height="178.356" transform="translate(49.065 42.429)" />
        <rect class="e" width="45.842" height="1.432" transform="translate(59.452 49.949)" />
        <rect class="f" width="45.842" height="1.432" transform="translate(59.452 56.395)" />
        <rect class="e" width="45.842" height="1.432" transform="translate(112.099 49.949)" />
        <rect class="e" width="45.842" height="1.432" transform="translate(119.26 90.78)" />
        <rect class="e" width="45.842" height="1.432" transform="translate(120.336 94.717)" />
        <rect class="e" width="45.842" height="1.432" transform="translate(122.486 98.658)" />
        <rect class="e" width="45.842" height="1.432" transform="translate(119.26 154.169)" />
        <rect class="e" width="45.842" height="1.432" transform="translate(120.336 158.11)" />
        <rect class="e" width="45.842" height="1.432" transform="translate(122.486 162.048)" />
        <g class="b" transform="translate(59.811 76.093)">
            <rect class="c" width="48.706" height="49.424" />
        </g>
        <rect class="g" width="47.94" height="47.274" transform="translate(60.118 77.169)" />
        <g class="b" transform="translate(61.807 80.034)">
            <rect class="c" width="44.713" height="30.799" />
        </g>
        <rect class="a" width="44.097" height="29.726" transform="translate(62.114 80.393)" />
        <g class="h" transform="translate(62.114 80.393)">
            <path class="i" d="M187.112,298.931l11.1-17.192,4.655,7.52L212.9,278.874l8.6,10.384,7.52-15.4,19.339,30.8-62.675-2.15Z" transform="translate(-190.851 -270.278)" />
            <circle class="i" cx="3.223" cy="3.223" r="3.223" transform="translate(1.635 1.073)" />
        </g>
        <g class="b" transform="translate(59.811 139.486)">
            <rect class="c" width="48.706" height="49.424" />
        </g>
        <rect class="g" width="47.94" height="47.274" transform="translate(60.118 140.559)" />
        <g class="b" transform="translate(61.807 143.427)">
            <rect class="c" width="44.713" height="30.799" />
        </g>
        <rect class="a" width="44.097" height="29.726" transform="translate(62.114 143.782)" />
        <g class="h" transform="translate(62.114 143.782)">
            <path class="j" d="M187.112,505.631l11.1-17.192,4.655,7.523L212.9,485.574l8.6,10.387,7.52-15.4,19.339,30.8-62.675-2.147Z" transform="translate(-190.851 -476.978)" />
            <circle class="j" cx="3.223" cy="3.223" r="3.223" transform="translate(1.635 1.076)" />
        </g>
        <g class="b" transform="translate(67.464 30.79)">
            <rect class="k" width="184.803" height="137.526" transform="translate(0 181.258) rotate(-78.76)" />
        </g>
        <rect class="a" width="178.356" height="133.229" transform="translate(69.988 208.534) rotate(-78.76)" />
        <rect class="e" width="94.551" height="1.432" transform="translate(112.648 43.56) rotate(11.24)" />
        <rect class="e" width="94.551" height="1.432" transform="translate(86.26 176.345) rotate(11.24)" />
        <rect class="e" width="73.062" height="1.432" transform="translate(84.652 184.421) rotate(11.24)" />
        <rect class="f" width="27.217" height="1.432" transform="translate(83.047 192.503) rotate(11.24)" />
        <rect class="f" width="47.274" height="1.432" transform="translate(111.039 51.641) rotate(11.24)" />
        <rect class="e" width="85.237" height="1.432" transform="translate(109.438 59.719) rotate(11.24)" />
        <rect class="l" width="20.771" height="1.432" transform="translate(107.83 67.8) rotate(11.24)" />
        <rect class="e" width="94.551" height="1.432" transform="translate(106.226 75.88) rotate(11.24)" />
        <g class="b" transform="translate(104.904 110.006)">
            <rect class="m" width="48.706" height="84.879" transform="translate(0 47.772) rotate(-78.76)" />
        </g>
        <rect class="a" width="83.805" height="47.633" transform="translate(114.869 110.462) rotate(11.24)" />
        <rect class="e" width="94.551" height="1.432" transform="translate(104.621 83.962) rotate(11.24)" />
        <rect class="n" width="10.387" height="34.74" transform="translate(122.22 118.496) rotate(11.24)" />
        <rect class="o" width="10.387" height="23.28" transform="translate(138.252 133.367) rotate(11.24)" />
        <rect class="p" width="10.387" height="12.534" transform="translate(154.427 147.536) rotate(11.24)" />
        <rect class="q" width="10.387" height="25.43" transform="translate(175.206 138.52) rotate(11.24)" />
        <path class="r" d="M694.618,377.377a47.806,47.806,0,1,0-7.82,72.82l34.559,35.945a2.328,2.328,0,0,0,3.291.064l8.611-8.28a2.328,2.328,0,0,0,.064-3.291l-34.55-35.942A47.811,47.811,0,0,0,694.618,377.377ZM683.854,435.17a34.194,34.194,0,1,1,.951-48.35A34.194,34.194,0,0,1,683.854,435.17Z" transform="translate(-479.501 -270.05)" />
        <path class="s" d="M678.964,487.6c-3.846,0-3.852,5.977,0,5.977S682.816,487.6,678.964,487.6Z" transform="translate(-523.636 -356.643)" />
        <path class="t" d="M716.11,425.153a28.722,28.722,0,0,0-24.776,12.8c-1.635,2.558,3.005,4.818,4.631,2.272,4.146-6.489,12.025-10.611,20.547-10.4a26.177,26.177,0,0,1,21.36,12.423c1.632,2.69,5.91.245,4.293-2.429C736.933,431.234,726.8,425.408,716.11,425.153Z" transform="translate(-533.975 -313.342)" />
        <path class="n" d="M706.848,371.457a47.806,47.806,0,1,0-7.82,72.817l34.556,35.948a2.328,2.328,0,0,0,3.291.064l8.611-8.28a2.328,2.328,0,0,0,.064-3.291l-34.559-35.945A47.811,47.811,0,0,0,706.848,371.457Zm-10.764,57.768a34.194,34.194,0,1,1,.951-48.35A34.194,34.194,0,0,1,696.084,429.226Z" transform="translate(-487.98 -265.945)" />
        <path class="u" d="M691.194,481.67c-3.846,0-3.852,5.977,0,5.977S695.046,481.67,691.194,481.67Z" transform="translate(-532.115 -352.531)" />
        <path class="u" d="M728.34,419.233a28.722,28.722,0,0,0-24.776,12.8c-1.635,2.558,3.005,4.818,4.631,2.272,4.146-6.489,12.025-10.611,20.547-10.4A26.177,26.177,0,0,1,750.1,436.33c1.632,2.69,5.91.245,4.293-2.429A31.729,31.729,0,0,0,728.34,419.233Z" transform="translate(-542.454 -309.237)" />
        <rect class="v" width="1.073" height="6.088" transform="translate(37.246 203.593)" />
        <rect class="v" width="1.073" height="6.088" transform="translate(40.828 206.099) rotate(90)" />
        <path class="w" d="M740.9,62.966a1.316,1.316,0,0,1-.733-1.592.633.633,0,0,0,.028-.147h0A.659.659,0,0,0,739,60.789h0a.631.631,0,0,0-.074.129,1.316,1.316,0,0,1-1.592.733.631.631,0,0,0-.147-.028h0a.659.659,0,0,0-.432,1.193h0a.632.632,0,0,0,.129.074,1.316,1.316,0,0,1,.733,1.592.633.633,0,0,0-.028.147h0a.659.659,0,0,0,1.2.432h0a.628.628,0,0,0,.074-.129,1.316,1.316,0,0,1,1.592-.733.632.632,0,0,0,.147.028h0a.659.659,0,0,0,.439-1.187h0A.633.633,0,0,0,740.9,62.966Z" transform="translate(-565.518 -60.54)" />
        <path class="x" d="M306.472,210.116a1.316,1.316,0,0,1-.733-1.592.631.631,0,0,0,.028-.147h0a.659.659,0,0,0-1.187-.439h0a.631.631,0,0,0-.074.129,1.316,1.316,0,0,1-1.592.733.632.632,0,0,0-.147-.028h0a.659.659,0,0,0-.439,1.187h0a.632.632,0,0,0,.129.074,1.316,1.316,0,0,1,.733,1.592.632.632,0,0,0-.028.147h0a.659.659,0,0,0,1.187.439h0a.633.633,0,0,0,.074-.129,1.316,1.316,0,0,1,1.592-.733.633.633,0,0,0,.147.028h0a.659.659,0,0,0,.439-1.187h0A.631.631,0,0,0,306.472,210.116Z" transform="translate(-264.323 -162.563)" />
        <path class="x" d="M924.252,817.376a1.316,1.316,0,0,1-.733-1.592.629.629,0,0,0,.028-.147h0a.659.659,0,0,0-1.187-.438h0a.633.633,0,0,0-.074.129,1.316,1.316,0,0,1-1.592.733.633.633,0,0,0-.147-.028h0a.659.659,0,0,0-.439,1.187h0a.629.629,0,0,0,.129.074,1.316,1.316,0,0,1,.733,1.592.633.633,0,0,0-.028.147h0a.659.659,0,0,0,1.187.439h0a.631.631,0,0,0,.074-.129,1.316,1.316,0,0,1,1.592-.733.636.636,0,0,0,.147.028h0a.659.659,0,0,0,.439-1.187h0A.632.632,0,0,0,924.252,817.376Z" transform="translate(-692.645 -583.591)" />
        <circle class="y" cx="2.15" cy="2.15" r="2.15" transform="translate(96.339 20.94)" />
        <circle class="y" cx="2.15" cy="2.15" r="2.15" transform="translate(250.339 47.799)" />
        <circle class="w" cx="2.15" cy="2.15" r="2.15" transform="translate(238.164 111.906)" />
        <circle class="z" cx="2.15" cy="2.15" r="2.15" transform="translate(0 6.613)" />
    </g>
</svg><?php /**PATH D:\dustin\laravel_proj\profiling\resources\views/svg/search-paper-icon.blade.php ENDPATH**/ ?>