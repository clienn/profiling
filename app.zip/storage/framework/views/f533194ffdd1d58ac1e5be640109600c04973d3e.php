<div id="no-search" class="row">
    <div class="col-md-11 mt-5 text-center">
        <?php echo $__env->make('svg.search-paper-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <p class="header-2 mt-5 fc-1 font-light">To start, type in member code or use<br />QR code scanner.</p>
    </div>
</div><?php /**PATH D:\dustin\laravel_proj\profiling\resources\views/includes/search-status.blade.php ENDPATH**/ ?>