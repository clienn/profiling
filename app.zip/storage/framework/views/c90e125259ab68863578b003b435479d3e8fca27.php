<div id="no-search" class="row">
    <div class="col-md-11 mt-5 text-center">
        <?php echo $__env->make('svg.not-found-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <p class="header-2 mt-5 fc-1 font-light">
            Search not found. <br />
            Type in branch name or address.</p>
    </div>
</div><?php /**PATH D:\dustin\laravel_proj\profiling\resources\views/includes/search-notfound-branch.blade.php ENDPATH**/ ?>