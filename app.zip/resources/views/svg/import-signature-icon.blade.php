<svg xmlns="http://www.w3.org/2000/svg" width="45.92" height="9" viewBox="0 0 45.92 9">
    <defs>
        <style>
            .a {
                fill: #999;
            }
        </style>
    </defs>
    <g transform="translate(-1229 -1248)">
        <circle class="a" cx="4.5" cy="4.5" r="4.5" transform="translate(1229 1248)" />
        <circle class="a" cx="4.5" cy="4.5" r="4.5" transform="translate(1247.46 1248)" />
        <circle class="a" cx="4.5" cy="4.5" r="4.5" transform="translate(1265.92 1248)" />
    </g>
</svg>