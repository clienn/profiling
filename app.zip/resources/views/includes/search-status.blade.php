<div id="no-search" class="row">
    <div class="col-md-11 mt-5 text-center">
        @include('svg.search-paper-icon')
        <p class="header-2 mt-5 fc-1 font-light">To start, type in member code or use<br />QR code scanner.</p>
    </div>
</div>