<div id="no-search" class="row">
    <div class="col-md-11 mt-5 text-center">
        @include('svg.not-found-icon')
        <p class="header-2 mt-5 fc-1 font-light">
            Search not found. <br />
            Type in member code or use QR code scanner.</p>
    </div>
</div>